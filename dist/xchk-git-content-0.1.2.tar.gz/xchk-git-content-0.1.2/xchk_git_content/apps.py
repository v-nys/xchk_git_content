from django.apps import AppConfig


class GitcontentConfig(AppConfig):
    name = 'xchk_git_content'
