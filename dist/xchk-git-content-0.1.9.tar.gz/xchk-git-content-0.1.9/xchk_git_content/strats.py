import regex
from xchk_core.strats import *
from xchk_regex_strategies.strats import RegexCheck
